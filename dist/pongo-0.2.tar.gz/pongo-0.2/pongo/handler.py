import SocketServer
import logging

class MongoException(Exception):
    """Exception raised when there is a communication problem with mongodb"""
    pass


class RequestHandler(SocketServer.StreamRequestHandler):
    """Hnadler for TCP requests coming from Postfix"""
    def handle(self):
        """Handle the request"""
        data = self.rfile.readline().strip()
        response = "400 Unknown error\n"
        try:
            method,email = data.split()
            assert method == "get"
        except:
            logging.warning("Invalid request: %s" % data)
        else:
            try:
                result = self.lookup(email)
                if result:
                    response = "200 %s\n" % self.server.args.string
                else:
                    response = "500 Not found\n"
            except MongoException,e:
                pass
        self.wfile.write(response)
    
    def lookup(self,key):
        """Lookup key in the specified mongo collection"""
        if not self.server.db:
            self.server.connect()
        try:
            count = self.server.db[self.server.args.collection].find({self.server.args.key_field:key}).count()
        except Exception,e:
            self.server.logger.critical("Error querying mongo database: %s" % str(e))
            raise MongoException
        if count > 0:
            self.server.logger.info("Query for %s: found" % key)
            return True
        else:
            self.server.logger.info("Query for %s: not found" % key)
            return False

